# HMCF Prime - Customer & Truck Assignment System

A simple internal web app for HMCF Prime Corporation staff to:
1. Keep a list of customers
2. Add/edit customer details through a form
3. Assign trucks/equipment to a customer's job and print the receipt / acknowledgement letter

**Stack:** PHP (REST API, PDO/MySQL) + AngularJS 1.8 (frontend, hash-routing, no build step) + MySQL.
No Node build tools, no Composer packages required — everything runs as plain files on standard
Hostinger shared hosting.

---

## 1. Folder structure

```
/api/            PHP REST endpoints (customers, trucks, assignments, auth)
/database/       schema.sql — run this once to create tables
/css/            stylesheet (mobile-first, works on phones/tablets/POS terminals)
/js/             AngularJS app, services, controllers
/partials/       AngularJS view templates
/print/          standalone printable receipt page
index.html       the app shell (loads AngularJS from CDN)
```

## 2. Deploy to Hostinger

1. **Create the database**
   - In hPanel go to *Databases → MySQL Databases*, create a database and a user, and note the
     database name, username, password (Hostinger prefixes these with `u123456789_`).
   - Open *phpMyAdmin*, select the new database, go to the **SQL** tab, and run the contents of
     `database/schema.sql`. This creates all tables and one default login.

2. **Upload the files**
   - Zip this whole folder and upload it via *File Manager* (or FTP) into `public_html/`
     (or a subfolder/subdomain such as `public_html/app/` → `app.hmcfprime.online`, recommended
     so this stays separate from the public marketing site).
   - Extract it there.

3. **Set your database credentials**
   - Edit `api/config.php` and fill in the real `DB_NAME`, `DB_USER`, `DB_PASS` from step 1.

4. **Log in**
   - Visit the app URL, e.g. `https://app.hmcfprime.online/`.
   - Default login: **username `admin`, password `admin123`**.
   - **Change this password immediately** — either add a "change password" query manually in
     phpMyAdmin (generate a new hash with PHP's `password_hash()`), or ask your developer to add
     a change-password screen.

That's it — no `npm install`, no Composer, no build step. AngularJS is loaded from a public CDN,
so the server only needs to serve static files and run PHP.

## 3. Using the app

- **Customers** — list, search, add, edit, archive. Archiving hides a customer from the active
  list without deleting their history (so old receipts still show correct customer info).
- **Trucks** — simple fleet list (plate number, type, capacity, status). Add your trucks here
  first; they're what populates the dropdown in the assignment form.
- **Assignments** — pick a customer + an available truck, fill in driver/service/location
  details, save. A receipt number is generated automatically (e.g. `HMCF-2026-0001`). After
  saving, click **Print Receipt / Acknowledgement Letter** to open a print-ready page — this
  works with regular printers as well as receipt/thermal printers connected to a terminal,
  since it's just the browser's native print dialog.

## 4. Mobile / terminal use

The interface is mobile-first:
- Layout, buttons, and form fields are sized for touchscreens (44px+ touch targets).
- Tables collapse into stacked cards on narrow screens instead of squeezing columns.
- The nav collapses into a menu button below 720px width.

It has been designed to work well on a phone, tablet, or a small POS-style terminal browser,
as well as full desktop screens.

## 5. Notes / things to customize

- `print/receipt.html` has a placeholder company address/phone/email in the header — update
  those to your real business details.
- The default admin account is meant for a single shared staff login. If you want separate
  logins per staff member, add rows to the `users` table (same permission level for all).
- `amount` on the assignment form is optional — leave it blank if you don't want pricing to
  appear on the printed receipt.

## 6. Security checklist before going live

- [ ] Change the default admin password
- [ ] Make sure the site is served over **HTTPS** (Hostinger provides free SSL — enable it in hPanel)
- [ ] Double-check `api/config.php` is not publicly downloadable (the included `.htaccess` blocks
      direct access to it, but confirm `mod_headers`/`.htaccess` overrides are allowed on your plan)
- [ ] Take a database backup regularly (hPanel → Backups)
