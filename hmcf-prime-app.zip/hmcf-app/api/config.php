<?php
/**
 * HMCF Prime - Database Configuration
 * ------------------------------------
 * Update these 4 values with the credentials from your Hostinger
 * hPanel -> Databases -> MySQL Databases screen.
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'u123456789_hmcf_prime');   // replace with your actual DB name
define('DB_USER', 'u123456789_hmcfadmin');    // replace with your actual DB user
define('DB_PASS', 'CHANGE_ME');               // replace with your actual DB password

// Session lifetime in seconds (8 hours)
define('SESSION_LIFETIME', 8 * 60 * 60);

// Timezone used for dates/receipt numbering
date_default_timezone_set('Asia/Manila');
