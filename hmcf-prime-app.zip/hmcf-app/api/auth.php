<?php
require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

if ($method === 'POST' && $action === 'login') {
    $body = get_json_body();
    $username = clean_str($body['username'] ?? '');
    $password = (string) ($body['password'] ?? '');

    if (!$username || !$password) {
        json_error('Username and password are required.');
    }

    $stmt = db()->prepare('SELECT id, username, password_hash, full_name FROM users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        json_error('Invalid username or password.', 401);
    }

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['full_name'] = $user['full_name'];

    json_success([
        'id' => $user['id'],
        'username' => $user['username'],
        'full_name' => $user['full_name'],
    ]);
}

if ($method === 'POST' && $action === 'logout') {
    $_SESSION = [];
    session_destroy();
    json_success(['message' => 'Logged out.']);
}

if ($method === 'GET' && $action === 'check') {
    if (empty($_SESSION['user_id'])) {
        json_error('Not authenticated.', 401);
    }
    json_success([
        'id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'],
        'full_name' => $_SESSION['full_name'],
    ]);
}

json_error('Unknown action.', 404);
